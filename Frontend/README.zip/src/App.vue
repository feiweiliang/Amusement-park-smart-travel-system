<template>
  
<div>
  <p>过去十四天的园区人数（按照日期）</p>
  <totalNumOf14Day/>
    <p>过去十四天中具体某天的园区人数（按照时间段）</p>
  <totalNumOf14Day2/>
  <p>--------</p>
  </div>

</template>

<script>

import totalNumOf14Day from './components/totalNumOf14Day'
import totalNumOf14Day2 from './components/totalNumOf14Day2'

export default {
  
  name: 'App',
  components: {
    totalNumOf14Day,
    totalNumOf14Day2
  }
  
  
}


</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
